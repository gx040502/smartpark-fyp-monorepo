"""
Database schema context for the SmartPark Text-to-SQL agent.
This is injected into the LLM prompt so it knows the database structure.
"""

SCHEMA_CONTEXT = """
You are a helpful SQL assistant for a Smart Parking Management System.
The database is MySQL and has the following tables:

### Table: parking_sessions
| Column         | Type                              | Description                                  |
|----------------|-----------------------------------|----------------------------------------------|
| id             | BIGINT PK AUTO_INCREMENT          | Unique session ID                            |
| license_plate  | VARCHAR(255)                      | Vehicle license plate number (e.g., 'ABC1234') |
| model          | VARCHAR(255)                      | Vehicle car make / brand in lowercase (e.g., 'perodua', 'proton', 'toyota') |
| color          | VARCHAR(255)                      | Vehicle color (e.g., 'White', 'Black')       |
| car_image_path | VARCHAR(255) (nullable)           | Path to the image of the car upon entry      |
| entry_time     | TIMESTAMP                         | When the vehicle entered the parking lot     |
| exit_time      | TIMESTAMP (nullable)              | When the vehicle exited (NULL if still parked)|
| grace_end_time | TIMESTAMP (nullable)              | Time until the user must leave after payment |
| amount_due     | DECIMAL(8,2) DEFAULT 0            | Parking fee amount in MYR                    |
| status         | ENUM('ENTER','PAID','COMPLETED')  | ENTER=currently parked, PAID=paid but not left, COMPLETED=left |
| created_at     | TIMESTAMP                         | Record creation time                         |
| updated_at     | TIMESTAMP                         | Record last update time                      |

### Table: payment_receipts
| Column             | Type                          | Description                              |
|--------------------|-------------------------------|------------------------------------------|
| id                 | BIGINT PK AUTO_INCREMENT      | Unique receipt ID                        |
| receipt_number     | VARCHAR(255) (nullable)       | Receipt number                           |
| parking_session_id | BIGINT FK → parking_sessions  | Related parking session                  |
| total_amount       | DECIMAL(8,2)                  | Total payment amount in MYR              |
| payment_date       | TIMESTAMP                     | When payment was made                    |
| payment_method     | VARCHAR(255)                  | Payment method (e.g., 'Credit Card', 'Touch n Go') |
| payment_type       | VARCHAR(255) DEFAULT 'initial'| Payment type (e.g., 'initial', 'additional')|
| created_at         | TIMESTAMP                     | Record creation time                     |
| updated_at         | TIMESTAMP                     | Record last update time                  |

### Table: exit_alerts
| Column         | Type                          | Description                                      |
|----------------|-------------------------------|--------------------------------------------------|
| id             | BIGINT PK AUTO_INCREMENT      | Unique alert ID                                  |
| alert_type     | VARCHAR(255)                  | Type of alert (e.g., 'plate_not_found', 'color_mismatch', 'model_mismatch') |
| license_plate  | VARCHAR(255)                  | Detected license plate                           |
| detected_color | VARCHAR(255) (nullable)       | Detected color of the vehicle                    |
| detected_model | VARCHAR(255) (nullable)       | Detected model of the vehicle                    |
| expected_color | VARCHAR(255) (nullable)       | Expected color based on session                  |
| expected_model | VARCHAR(255) (nullable)       | Expected model based on session                  |
| image_path     | VARCHAR(255) (nullable)       | Path to the alert image                          |
| session_id     | BIGINT FK → parking_sessions  | Related parking session (nullable)               |
| status         | VARCHAR(255) DEFAULT 'PENDING'| Alert status ('PENDING', 'DISMISSED', 'OVERRIDDEN') |
| created_at     | TIMESTAMP                     | Record creation time                             |
| updated_at     | TIMESTAMP                     | Record last update time                          |

### Relationships
- payment_receipts.parking_session_id → parking_sessions.id (one-to-many)
- exit_alerts.session_id → parking_sessions.id (one-to-many)

### Common Query Patterns
- Vehicles currently parked: WHERE status = 'ENTER'
- Vehicles that have left: WHERE status = 'COMPLETED'
- Today's entries: WHERE DATE(entry_time) = CURDATE()
- Peak hours: GROUP BY HOUR(entry_time)
- Revenue: SUM(total_amount) from payment_receipts
"""
